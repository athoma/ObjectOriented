package aptyt7stopwatch;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;


public class Aptyt7Stopwatch extends Application {
    
    private ImageView hand;
    private Integer elapsedTime = 0;
    private Integer minutes = 0;
    private Integer time;
    GridPane grid = new GridPane();
    
    Timeline timeLine;
    Timeline digital;
    
    @Override
    public void start(Stage primaryStage) {
        
        VBox root = new VBox();
        root.setAlignment(Pos.CENTER);
        
        ImageView clockFace = new ImageView();
        Image clockFaceImage = new Image(this.getClass().getResourceAsStream("clockface.png"));
        clockFace.setImage(clockFaceImage);
        
        hand = new ImageView();
        Image handImage = new Image(this.getClass().getResourceAsStream("hand.png"));
        hand.setImage(handImage);
        
        StackPane stack = new StackPane();
        stack.setAlignment(Pos.TOP_CENTER);
        stack.getChildren().addAll(clockFace, hand);
        
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(10);
        grid.setVgap(10);
        
        Button stop = new Button();
        stop.setText("STOP");
        stop.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                stopStopwatch();
            }
        });
        
        Button start = new Button();
        start.setText("START");
        start.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                startStopwatch();
            }
        });
        
        Button reset = new Button();
        reset.setText("RESET");
        reset.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                resetStopwatch();
            }
        });
        
        grid.add(start, 0, 0);
        grid.add(stop, 1, 0);
        grid.add(reset, 2, 0);
        
        updateDigital();
        
        root.getChildren().addAll(stack, grid);
        Scene scene = new Scene(root, 500, 500);
        
        primaryStage.setTitle("Stopwatch");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        timeLine = new Timeline(new KeyFrame(Duration.millis(1000), actionEvent -> updateStopwatch() ));
        timeLine.setCycleCount(Animation.INDEFINITE);
        timeLine.play();
        
        digital = new Timeline(new KeyFrame(Duration.millis(1000), actionEvent -> updateDigital() ));
        digital.setCycleCount(Animation.INDEFINITE);
        digital.play();
      
    }
    
    public void updateStopwatch() {
        elapsedTime++;
        Integer rotation = elapsedTime * 6;
        hand.setRotate(rotation);
    }

    public void resetStopwatch () {
        elapsedTime = 0;
        minutes = 0;
        time = 0;
        updateDigital();
        hand.setRotate(elapsedTime);
        timeLine.stop();
    }
    
    public void stopStopwatch () {
        timeLine.stop();
        digital.stop();
    }
    
    public void startStopwatch () {
        timeLine.setCycleCount(Animation.INDEFINITE);
        timeLine.play();
        digital.setCycleCount(Animation.INDEFINITE);
        digital.play();
    }
    
    public void updateDigital () {
        
        time = elapsedTime;
        if (time >= 60) {
            time = 0;
            elapsedTime = 0;
            minutes++;
        }
        
        TextField digitalTime = new TextField();
        digitalTime.setPrefSize(3, 3);
        digitalTime.setAlignment(Pos.CENTER);
        
        if (time < 10 && minutes < 1) {
            digitalTime.setText("0:0"+time);
        } else if (time < 10 && minutes >= 1) {
            digitalTime.setText(minutes+":0"+time);
        } else {
            digitalTime.setText(minutes+":"+time);
        }
        
        grid.add(digitalTime, 1, 1);
        
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}

