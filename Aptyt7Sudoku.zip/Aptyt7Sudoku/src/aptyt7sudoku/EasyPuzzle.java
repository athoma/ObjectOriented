/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aptyt7sudoku;

import javafx.scene.control.TextField;

/**
 *
 * @author athomaperry
 */
public class EasyPuzzle {
    
    private int[] loadArray = { 
        9, 0, 3, 0, 6, 0, 8, 7, 0,
        0, 0, 0, 3, 0, 0, 9, 0, 6,
        0, 0, 0, 8, 4, 0, 0, 1, 3,
        0, 9, 0, 7, 8, 0, 0, 0, 0,
        7, 0, 8, 4, 2, 1, 5, 3, 9,
        0, 0, 0, 0, 9, 6, 0, 4, 0,
        3, 7, 0, 0, 5, 8, 0, 0, 0,
        1, 0, 6, 9, 7, 4, 3, 8, 5,
        0, 4, 5, 0, 3, 0, 1, 0, 7
    };
    
    private int[] fullArray = { 
        9, 1, 3, 2, 6, 5, 8, 7, 4,
        4, 8, 2, 3, 1, 7, 9, 5, 6,
        6, 5, 7, 8, 4, 9, 2, 1, 3,
        5, 9, 4, 7, 8, 3, 6, 2, 1,
        7, 6, 8, 4, 2, 1, 5, 3, 9,
        2, 3, 1, 5, 9, 6, 7, 4, 8,
        3, 7, 9, 1, 5, 8, 4, 6, 2,
        1, 2, 6, 9, 7, 4, 3, 8, 5,
        8, 4, 5, 6, 3, 2, 1, 9, 7
    };
    
    void loadPuzzle(){
        
    }
    
    
} 

