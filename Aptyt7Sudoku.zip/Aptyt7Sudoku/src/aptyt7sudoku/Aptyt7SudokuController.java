/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aptyt7sudoku;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javax.swing.JTextField;

/**
 *
 * @author athomaperry
 */


public class Aptyt7SudokuController implements Initializable {
    
    @FXML
    private GridPane gridpane;
    
    @FXML
    public TextField  zero, one, two, three, four, five, six, seven, eight, nine, 
            ten, eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen,
            twenty, twenty1, twenty2, twenty3, twenty4, twenty5, twenty6, twenty7, twenty8, twenty9,
            thirty, thirty1, thirty2, thirty3, thirty4, thirty5, thirty6, thirty7, thirty8, thirty9,
            fourty, fourty1, fourty2, fourty3, fourty4, fourty5, fourty6, fourty7, fourty8, fourty9, 
            fifty, fifty1, fifty2, fifty3, fifty4, fifty5, fifty6, fifty7, fifty8, fifty9,
            sixty, sixty1, sixty2, sixty3, sixty4, sixty5, sixty6, sixty7, sixty8, sixty9,
            seventy, seventy1, seventy2, seventy3, seventy4, seventy5, seventy6, seventy7, seventy8, seventy9,
            eighty;
  
   
    TextField[] c = {
            zero, one, two, three, four, five, six, seven, eight, nine, 
            ten, eleven, twelve, thirteen, fourteen, fifteen, sixteen, seventeen, eighteen, nineteen,
            twenty, twenty1, twenty2, twenty3, twenty4, twenty5, twenty6, twenty7, twenty8, twenty9,
            thirty, thirty1, thirty2, thirty3, thirty4, thirty5, thirty6, thirty7, thirty8, thirty9,
            fourty, fourty1, fourty2, fourty3, fourty4, fourty5, fourty6, fourty7, fourty8, fourty9, 
            fifty, fifty1, fifty2, fifty3, fifty4, fifty5, fifty6, fifty7, fifty8, fifty9,
            sixty, sixty1, sixty2, sixty3, sixty4, sixty5, sixty6, sixty7, sixty8, sixty9,
            seventy, seventy1, seventy2, seventy3, seventy4, seventy5, seventy6, seventy7, seventy8, seventy9,
            eighty
    };
        
    
    
    
    
    private ArrayList<FieldArray> fieldarray;
    private FieldArray currentfieldarray;
    
    
    private int i = 0;
    
    private ArrayList a = new ArrayList();
    private ArrayList b = new ArrayList();
    
    private final int[] puzzle = { 
        9, 0, 3, 0, 6, 0, 8, 7, 0,
        0, 0, 0, 3, 0, 0, 9, 0, 6,
        0, 0, 0, 8, 4, 0, 0, 1, 3,
        0, 9, 0, 7, 8, 0, 0, 0, 0,
        7, 0, 8, 4, 2, 1, 5, 3, 9,
        0, 0, 0, 0, 9, 6, 0, 4, 0,
        3, 7, 0, 0, 5, 8, 0, 0, 0,
        1, 0, 6, 9, 7, 4, 3, 8, 5,
        0, 4, 5, 0, 3, 0, 1, 0, 7
    };

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    
        
        
        //a.add(zero);
        //b.add("9");
        
        //a.get(0) = value;
        //for (int i = 0; i < 3; i++){
            //a.get(0).equals(b.get(0));
        //}
       //x = c[4].getUserData();
       
       
       zero.setText("1");
       System.out.println(c.length);
       //c[0].setText("");
       
      
       
        
    }    
        
        /*public void loadArray (){
            if (puzzle[i] != 0) {
                
            }
        }*/
    
    /*public void textArray() {
        
        TextField a[] = new TextField[]{};
        a[0] = zero;
        a[1] = one;
        a[2] = two;
        a[3] = three;
        
        for (int i = 0; i < 3; i++){
            a[i].setText(""+loadarray[i]);
        }
    };*/
        
}
    
