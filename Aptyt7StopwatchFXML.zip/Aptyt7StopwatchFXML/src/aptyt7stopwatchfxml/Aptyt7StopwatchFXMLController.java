/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aptyt7stopwatchfxml;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author athomaperry
 */
public class Aptyt7StopwatchFXMLController implements Initializable {

    @FXML
    private ImageView hand;
    
    @FXML
    private Label digitalClock;
    
    private Timeline timeLine;
    private int elapsedTime;
    private int minutes;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        digitalClock.setText("00:00");
        timeLine = new Timeline(new KeyFrame(Duration.millis(1000), actionEvent -> update() ));
        timeLine.setCycleCount(Animation.INDEFINITE);
        timeLine.play();
    }    
    
    public void ready(){
        
    }
    @FXML
    public void handleStart(ActionEvent event) {
        timeLine.setCycleCount(Animation.INDEFINITE);
        timeLine.play();
        //hand.setRotate(90);
        //digitalClock.setText("00:15");
    }
    
    @FXML
    public void handleStop(ActionEvent event) {
        timeLine.stop();
    }
    
    @FXML
    public void handleReset(ActionEvent event) {
        elapsedTime = 0;
        minutes = 0;
        updateHand();
        updateDigitalclock();
        timeLine.stop();
    }
    
    public void update() {
        elapsedTime++;
        updateHand();
        updateDigitalclock();
    }
    
    private void updateHand() {
        Integer rotation = elapsedTime * 6;
        hand.setRotate(rotation);
    }
    
    private void updateDigitalclock() {
        int time = elapsedTime;
        if (time >= 60) {
            time = 0;
            elapsedTime = 0;
            minutes++;
        }
        
        if (time < 10 && minutes < 1) {
            digitalClock.setText("00:0"+time);
        } else if (time < 10 && minutes >= 1 && minutes < 10) {
            digitalClock.setText("0"+minutes+":0"+time);
        } else if (time >= 10 && minutes >= 1 && minutes < 10) {
            digitalClock.setText("0"+minutes+":"+time);
        } else if (time >= 10 && minutes < 1) {
            digitalClock.setText("00:"+time);
        } else {
            digitalClock.setText(minutes+":"+time);
        }
    }
}
